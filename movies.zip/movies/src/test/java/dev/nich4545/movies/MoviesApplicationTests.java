package dev.nich4545.movies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesApplicationTests {

	@Test
	void contextLoads() {
	}

}
